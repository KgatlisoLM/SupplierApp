import axios, { AxiosInstance } from 'axios';
import type { CreateSupplierRequest, SupplierDto, SupplierSummaryDto } from './types';

export function createApiClient(baseURL: string): AxiosInstance {
  return axios.create({
    baseURL,
    timeout: 10000,
    headers: { 'Content-Type': 'application/json' }
  });
}

export async function createSupplier(api: AxiosInstance, payload: CreateSupplierRequest) {
  const response = await api.post<SupplierDto>('/suppliers', payload);
  return response.data;
}

export async function searchSuppliers(api: AxiosInstance, companyName: string) {
  const response = await api.get<SupplierDto[]>('/suppliers/search', {
    params: { companyName }
  });
  return response.data;
}

export async function getSupplierSummary(api: AxiosInstance) {
  const response = await api.get<SupplierSummaryDto>('/suppliers/summary');
  return response.data;
}
