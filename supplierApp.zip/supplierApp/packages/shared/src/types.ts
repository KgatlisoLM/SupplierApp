export interface SupplierDto {
  id?: number;
  code: string;
  companyName: string;
  telephoneNumber: string;
}

export interface CreateSupplierRequest {
  code: string;
  companyName: string;
  telephoneNumber: string;
}

export interface SupplierSummaryDto {
  totalSuppliers: number;
  recentSuppliers: SupplierDto[];
}
