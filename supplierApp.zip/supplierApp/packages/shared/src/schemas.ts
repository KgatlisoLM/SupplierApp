import { z } from 'zod';

export const supplierSchema = z.object({
  code: z
    .string()
    .trim()
    .min(1, 'Code is required.')
    .max(10, 'Code must be 10 characters or less.'),
  companyName: z
    .string()
    .trim()
    .min(1, 'Company name is required.')
    .max(200, 'Company name must be 200 characters or less.'),
  telephoneNumber: z
    .string()
    .trim()
    .min(1, 'Telephone number is required.')
    .max(20, 'Telephone number must be 20 characters or less.')
});

export const searchSchema = z.object({
  companyName: z
    .string()
    .trim()
    .min(1, 'Please enter a company name to search.')
});

export type SupplierFormValues = z.infer<typeof supplierSchema>;
export type SearchFormValues = z.infer<typeof searchSchema>;
