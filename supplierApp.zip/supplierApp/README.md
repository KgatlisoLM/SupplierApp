# Supplier Monorepo

Monorepo containing:
- `apps/mobile` — Expo React Native app
- `apps/web` — React + Vite web app
- `packages/shared` — shared DTOs, Zod schemas, API client, and helper utilities

## Prerequisites
- Node.js 20+
- npm 10+
- Running ASP.NET Core API

## Install
```bash
npm install
```

## Environment variables
Create these files:

### `apps/mobile/.env`
```env
EXPO_PUBLIC_API_URL=http://YOUR_IP:5077/api
```

### `apps/web/.env`
```env
VITE_API_URL=http://localhost:5077/api
```

## Run web
```bash
npm run dev:web
```

## Run mobile
```bash
npm run dev:mobile
```

## Notes
- Mobile should use your machine IP, not `localhost`, when testing on a real device.
- The shared package keeps the request/response contract aligned between web and mobile.
