import { createApiClient } from '@supplier/shared';

const baseURL = process.env.EXPO_PUBLIC_API_URL ?? '';

export const api = createApiClient(baseURL);
