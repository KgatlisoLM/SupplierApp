import {
  createSupplier,
  getSupplierSummary,
  searchSuppliers,
  type CreateSupplierRequest,
  type SupplierDto,
  type SupplierSummaryDto,
} from '@supplier/shared';
import { api } from './client';

export { type CreateSupplierRequest, type SupplierDto, type SupplierSummaryDto };

export async function createSupplierRequest(payload: CreateSupplierRequest) {
  return createSupplier(api, payload);
}

export async function searchSupplierRecords(companyName: string) {
  return searchSuppliers(api, companyName);
}

export async function getSummary() {
  return getSupplierSummary(api);
}
