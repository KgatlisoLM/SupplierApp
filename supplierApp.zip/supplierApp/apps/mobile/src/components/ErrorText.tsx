import { StyleSheet, Text } from "react-native";
import { colors } from "../constants/colors";

type Props = {
  message?: string | null;
};

export default function ErrorText({ message }: Props) {
  if (!message) return null;

  return <Text style={styles.text}>{message}</Text>;
}

const styles = StyleSheet.create({
  text: {
    color: colors.danger,
    marginTop: 10,
    marginBottom: 10,
    fontSize: 13,
  },
});
