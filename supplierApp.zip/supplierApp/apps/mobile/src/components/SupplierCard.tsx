import { StyleSheet, Text, View } from "react-native";
import { SupplierDto } from "../types/supplier";
import { colors } from "../constants/colors";

type Props = {
  supplier: SupplierDto;
};

export default function SupplierCard({ supplier }: Props) {
  return (
    <View style={styles.card}>
      <Text style={styles.name}>{supplier.companyName}</Text>
      {!!supplier.code && (
        <Text style={styles.meta}>Code: {supplier.code}</Text>
      )}
      <Text style={styles.meta}>Phone: {supplier.telephoneNumber}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 14,
    padding: 14,
    marginBottom: 12,
  },
  name: {
    fontSize: 16,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 6,
  },
  meta: {
    color: colors.muted,
  },
});
