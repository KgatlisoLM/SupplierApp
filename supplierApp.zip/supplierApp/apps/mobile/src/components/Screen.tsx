import { PropsWithChildren } from "react";
import { StyleSheet, View } from "react-native";
import { colors } from "../constants/colors";
import { SafeAreaView } from "react-native-safe-area-context";

export default function Screen({ children }: PropsWithChildren) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>{children}</View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: colors.background,
  },
  container: {
    flex: 1,
    padding: 16,
  },
});
