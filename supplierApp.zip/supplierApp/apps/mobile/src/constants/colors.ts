export const colors = {
  background: "#F7F8FA",
  card: "#FFFFFF",
  text: "#111827",
  muted: "#6B7280",
  primary: "#2563EB",
  border: "#E5E7EB",
  success: "#16A34A",
  danger: "#DC2626",
};
