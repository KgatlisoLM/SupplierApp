export { supplierSchema, type SupplierFormValues } from '@supplier/shared';
