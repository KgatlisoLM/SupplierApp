export type FieldErrors<T extends string> = Partial<Record<T, string>>;

type ZodLikeIssue = {
  path: PropertyKey[];
  message: string;
};

export function mapZodErrors<T extends string>(
  issues: ZodLikeIssue[],
): FieldErrors<T> {
  return issues.reduce((acc, issue) => {
    const key = issue.path[0];

    if (typeof key === "string" && !acc[key as T]) {
      acc[key as T] = issue.message;
    }

    return acc;
  }, {} as FieldErrors<T>);
}
