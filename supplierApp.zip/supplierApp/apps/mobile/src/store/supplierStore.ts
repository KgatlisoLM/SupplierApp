import { create } from "zustand";
import { createSupplierRequest, getSummary, searchSupplierRecords } from '../api/suppliers';
import { supplierSchema, type CreateSupplierRequest, type SupplierDto, type SupplierSummaryDto } from '@supplier/shared';

type SupplierStore = {
  summary: SupplierSummaryDto | null;
  searchResults: SupplierDto[];

  loadingSummary: boolean;
  loadingSearch: boolean;
  loadingCreate: boolean;

  summaryError: string | null;
  searchError: string | null;
  createError: string | null;

  fetchSummary: () => Promise<void>;
  runSearch: (companyName: string) => Promise<void>;
  addSupplier: (payload: CreateSupplierRequest) => Promise<void>;

  clearSearch: () => void;
  clearErrors: () => void;
};

export const useSupplierStore = create<SupplierStore>((set) => ({
  summary: null,
  searchResults: [],

  loadingSummary: false,
  loadingSearch: false,
  loadingCreate: false,

  summaryError: null,
  searchError: null,
  createError: null,

  fetchSummary: async () => {
    try {
      set({
        loadingSummary: true,
        summaryError: null,
      });

      const data = await getSummary();

      set({
        summary: data,
      });
    } catch {
      set({
        summary: null,
        summaryError: "Could not load supplier summary.",
      });
    } finally {
      set({
        loadingSummary: false,
      });
    }
  },

  runSearch: async (companyName: string) => {
    const query = companyName.trim();

    if (!query) {
      set({
        searchResults: [],
        searchError: "Please enter a company name to search.",
      });
      return;
    }

    try {
      set({
        loadingSearch: true,
        searchError: null,
      });

      const data = await searchSupplierRecords(query);

      set({
        searchResults: Array.isArray(data) ? data : [],
      });
    } catch (error: any) {
      const apiMessage =
        error?.response?.data?.detail ||
        error?.response?.data?.title ||
        "Could not fetch suppliers.";

      set({
        searchResults: [],
        searchError: apiMessage,
      });
    } finally {
      set({
        loadingSearch: false,
      });
    }
  },

  addSupplier: async (payload: CreateSupplierRequest) => {
    const parsed = supplierSchema.safeParse(payload);

    if (!parsed.success) {
      const firstIssue =
        parsed.error.issues[0]?.message ?? "Invalid supplier details.";

      set({
        createError: firstIssue,
      });

      throw new Error(firstIssue);
    }

    try {
      set({
        loadingCreate: true,
        createError: null,
      });

      await createSupplierRequest(parsed.data);
      const updatedSummary = await getSummary();

      set({
        summary: updatedSummary,
      });
    } catch (error: any) {
      console.log("CREATE SUPPLIER ERROR FULL:", error?.response?.data);

      const apiMessage =
        error?.response?.data?.detail ||
        error?.response?.data?.title ||
        error?.response?.data?.message ||
        JSON.stringify(error?.response?.data?.errors) ||
        "Could not save supplier.";

      set({
        createError: apiMessage,
      });

      throw new Error(apiMessage);
    } finally {
      set({
        loadingCreate: false,
      });
    }
  },

  clearSearch: () =>
    set({
      searchResults: [],
      searchError: null,
    }),

  clearErrors: () =>
    set({
      summaryError: null,
      searchError: null,
      createError: null,
    }),
}));
