import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import HomeScreen from "../screens/HomeScreen";
import AddSupplierScreen from "../screens/AddSupplierScreen";
import SearchSupplierScreen from "../screens/SearchSupplierScreen";


const Tab = createBottomTabNavigator();

export default function AppNavigator() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: true }} >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Add Supplier" component={AddSupplierScreen} />
      <Tab.Screen name="Search" component={SearchSupplierScreen} />
    </Tab.Navigator>
  );
}
