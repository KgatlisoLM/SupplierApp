import { useState } from "react";
import { FlatList } from "react-native";
import Button from "../components/Button";
import Input from "../components/Input";
import Screen from "../components/Screen";
import EmptyState from "../components/EmptyState";
import ErrorText from "../components/ErrorText";
import SupplierCard from "../components/SupplierCard";
import { useSupplierStore } from "../store/supplierStore";

export default function SearchSupplierScreen() {
  const [query, setQuery] = useState("");

  const searchResults = useSupplierStore((state) => state.searchResults);
  const loadingSearch = useSupplierStore((state) => state.loadingSearch);
  const searchError = useSupplierStore((state) => state.searchError);
  const runSearch = useSupplierStore((state) => state.runSearch);

  async function handleSearch() {
    await runSearch(query);
  }

  return (
    <Screen>
      <Input
        label="Search Company"
        value={query}
        onChangeText={setQuery}
        placeholder="Search by company name"
      />

      <ErrorText message={searchError} />

      <Button
        title="Search"
        onPress={handleSearch}
        loading={loadingSearch}
      />

      <FlatList
        style={{ marginTop: 16 }}
        data={searchResults}
        keyExtractor={(item, index) =>
          `${item.id ?? item.companyName}-${index}`
        }
        renderItem={({ item }) => <SupplierCard supplier={item} />}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          !loadingSearch ? (
            <EmptyState
              title="No suppliers found"
              subtitle="Try a full or partial company name."
            />
          ) : null
        }
      />
    </Screen>
  );
}
