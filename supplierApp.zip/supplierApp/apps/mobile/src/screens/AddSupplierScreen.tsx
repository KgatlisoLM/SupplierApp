import { useState } from "react";
import { Alert } from "react-native";
import Button from "../components/Button";
import Input from "../components/Input";
import Screen from "../components/Screen";
import ErrorText from "../components/ErrorText";
import { supplierSchema, SupplierFormValues } from "../schemas/supplierSchema";
import { useSupplierStore } from "../store/supplierStore";
import { mapZodErrors, FieldErrors } from "../utils/zodErrors";

export default function AddSupplierScreen() {
  const [values, setValues] = useState<SupplierFormValues>({
    code: "",
    companyName: "",
    telephoneNumber: "",
  });

  const [fieldErrors, setFieldErrors] = useState<
    FieldErrors<"companyName" | "telephoneNumber" | "code">
  >({});

  const addSupplier = useSupplierStore((state) => state.addSupplier);
  const loadingCreate = useSupplierStore((state) => state.loadingCreate);
  const createError = useSupplierStore((state) => state.createError);

  function updateField<K extends keyof SupplierFormValues>(
    key: K,
    value: SupplierFormValues[K],
  ) {
    setValues((prev) => ({ ...prev, [key]: value }));

    if (fieldErrors[key]) {
      setFieldErrors((prev) => ({ ...prev, [key]: undefined }));
    }
  }

  async function handleSave() {
    const parsed = supplierSchema.safeParse(values);

    if (!parsed.success) {
      setFieldErrors(
        mapZodErrors<"companyName" | "telephoneNumber" | "code">(parsed.error.issues),
      );
      return;
    }

    setFieldErrors({});

    try {
      await addSupplier(parsed.data);
      setValues({
        code: "",
        companyName: "",
        telephoneNumber: "",
      });
      Alert.alert("Success", "Supplier saved successfully.");
    } catch {}
  }

  return (
    <Screen>
      <Input
        label="Company Name"
        value={values.companyName}
        onChangeText={(text) => updateField("companyName", text)}
        placeholder="Enter company name"
        error={fieldErrors.companyName}
      />
      <Input
        label="Code"
        value={values.code}
        onChangeText={(text) => updateField("code", text)}
        placeholder="Enter code"
        keyboardType="phone-pad"
        error={fieldErrors.code}
      />

      <Input
        label="Telephone Number"
        value={values.telephoneNumber}
        onChangeText={(text) => updateField("telephoneNumber", text)}
        placeholder="Enter telephone number"
        keyboardType="phone-pad"
        error={fieldErrors.telephoneNumber}
      />

      <ErrorText message={createError} />

      <Button
        title="Save Supplier"
        onPress={handleSave}
        loading={loadingCreate}
      />
    </Screen>
  );
}
