import { useEffect } from "react";
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Screen from "../components/Screen";
import EmptyState from "../components/EmptyState";
import ErrorText from "../components/ErrorText";
import SupplierCard from "../components/SupplierCard";
import { colors } from "../constants/colors";
import { useSupplierStore } from "../store/supplierStore";

export default function HomeScreen() {
  const summary = useSupplierStore((state) => state.summary);
  const loadingSummary = useSupplierStore((state) => state.loadingSummary);
  const summaryError = useSupplierStore((state) => state.summaryError);
  const fetchSummary = useSupplierStore((state) => state.fetchSummary);

  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);

  const recentSuppliers = summary?.recentSuppliers ?? [];
  const totalSuppliers = summary?.totalSuppliers ?? 0;

  return (
    <Screen>
      <View style={styles.hero}>
        <Text style={styles.title}>Supplier App</Text>
        <Text style={styles.subtitle}>
          Add suppliers and search supplier contact details.
        </Text>
      </View>

      <View style={styles.statsCard}>
        <Text style={styles.statsLabel}>Total Suppliers</Text>
        <Text style={styles.statsValue}>{totalSuppliers}</Text>
      </View>

      <Text style={styles.sectionTitle}>Recent Suppliers</Text>

      <ErrorText message={summaryError} />

      {loadingSummary ? (
        <ActivityIndicator style={{ marginTop: 20 }} />
      ) : recentSuppliers.length === 0 ? (
        <EmptyState
          title="No suppliers yet"
          subtitle="Once suppliers are added, they will appear here."
        />
      ) : (
        <FlatList
          data={recentSuppliers}
          keyExtractor={(item, index) =>
            `${item.id ?? item.companyName}-${index}`
          }
          renderItem={({ item }) => <SupplierCard supplier={item} />}
          showsVerticalScrollIndicator={false}
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 14,
  },
  title: {
    fontSize: 24,
    fontWeight: "800",
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    color: colors.muted,
    lineHeight: 20,
  },
  statsCard: {
    backgroundColor: colors.card,
    borderRadius: 16,
    padding: 18,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 16,
  },
  statsLabel: {
    color: colors.muted,
    marginBottom: 6,
  },
  statsValue: {
    fontSize: 28,
    fontWeight: "800",
    color: colors.text,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: colors.text,
    marginBottom: 12,
  },
});
