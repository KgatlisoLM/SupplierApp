import { create } from 'zustand';
import {
  createSupplier,
  getSupplierSummary,
  mapZodErrors,
  searchSchema,
  searchSuppliers,
  supplierSchema,
  type CreateSupplierRequest,
  type FieldErrors,
  type SupplierDto,
  type SupplierSummaryDto,
} from '@supplier/shared';
import { api } from './lib/api';

export type SupplierStore = {
  summary: SupplierSummaryDto | null;
  searchResults: SupplierDto[];
  loadingSummary: boolean;
  loadingSearch: boolean;
  loadingCreate: boolean;
  summaryError: string | null;
  searchError: string | null;
  createError: string | null;
  fetchSummary: () => Promise<void>;
  runSearch: (companyName: string) => Promise<void>;
  addSupplier: (payload: CreateSupplierRequest) => Promise<FieldErrors<'code' | 'companyName' | 'telephoneNumber'> | null>;
};

export const useSupplierStore = create<SupplierStore>((set) => ({
  summary: null,
  searchResults: [],
  loadingSummary: false,
  loadingSearch: false,
  loadingCreate: false,
  summaryError: null,
  searchError: null,
  createError: null,

  fetchSummary: async () => {
    try {
      set({ loadingSummary: true, summaryError: null });
      const data = await getSupplierSummary(api);
      set({ summary: data });
    } catch (error: any) {
      set({ summary: null, summaryError: error?.response?.data?.detail ?? 'Could not load supplier summary.' });
    } finally {
      set({ loadingSummary: false });
    }
  },

  runSearch: async (companyName: string) => {
    const parsed = searchSchema.safeParse({ companyName });
    if (!parsed.success) {
      set({ searchResults: [], searchError: mapZodErrors<'companyName'>(parsed.error.issues).companyName ?? 'Please enter a company name to search.' });
      return;
    }

    try {
      set({ loadingSearch: true, searchError: null });
      const data = await searchSuppliers(api, parsed.data.companyName);
      set({ searchResults: data });
    } catch (error: any) {
      set({ searchResults: [], searchError: error?.response?.data?.detail ?? 'Could not fetch suppliers.' });
    } finally {
      set({ loadingSearch: false });
    }
  },

  addSupplier: async (payload) => {
    const parsed = supplierSchema.safeParse(payload);
    if (!parsed.success) {
      set({ createError: parsed.error.issues[0]?.message ?? 'Invalid supplier details.' });
      return mapZodErrors<'code' | 'companyName' | 'telephoneNumber'>(parsed.error.issues);
    }

    try {
      set({ loadingCreate: true, createError: null });
      await createSupplier(api, parsed.data);
      const summary = await getSupplierSummary(api);
      set({ summary });
      return null;
    } catch (error: any) {
      set({ createError: error?.response?.data?.detail ?? error?.response?.data?.title ?? 'Could not save supplier.' });
      return null;
    } finally {
      set({ loadingCreate: false });
    }
  },
}));
