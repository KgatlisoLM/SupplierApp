import type { ButtonHTMLAttributes, PropsWithChildren } from 'react';

type Props = ButtonHTMLAttributes<HTMLButtonElement> & PropsWithChildren;

export function Button({ children, ...props }: Props) {
  return (
    <button className="button" {...props}>
      {children}
    </button>
  );
}
