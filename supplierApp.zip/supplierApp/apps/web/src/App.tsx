import { useEffect, useMemo, useState } from "react";
import { Card } from "./components/Card";
import { Input } from "./components/Input";
import { Button } from "./components/Button";
import { useSupplierStore } from "./store";
import type { CreateSupplierRequest } from "@supplier/shared";

const initialForm: CreateSupplierRequest = {
  code: "",
  companyName: "",
  telephoneNumber: "",
};

export default function App() {
  const [tab, setTab] = useState<"overview" | "add" | "search">("overview");
  const [form, setForm] = useState<CreateSupplierRequest>(initialForm);
  const [searchTerm, setSearchTerm] = useState("");
  const [fieldErrors, setFieldErrors] = useState<
    Partial<Record<"code" | "companyName" | "telephoneNumber", string>>
  >({});

  const summary = useSupplierStore((state) => state.summary);
  const searchResults = useSupplierStore((state) => state.searchResults);
  const loadingSummary = useSupplierStore((state) => state.loadingSummary);
  const loadingSearch = useSupplierStore((state) => state.loadingSearch);
  const loadingCreate = useSupplierStore((state) => state.loadingCreate);
  const summaryError = useSupplierStore((state) => state.summaryError);
  const searchError = useSupplierStore((state) => state.searchError);
  const createError = useSupplierStore((state) => state.createError);
  const fetchSummary = useSupplierStore((state) => state.fetchSummary);
  const runSearch = useSupplierStore((state) => state.runSearch);
  const addSupplier = useSupplierStore((state) => state.addSupplier);

  useEffect(() => {
    fetchSummary();
  }, [fetchSummary]);

  const recentSuppliers = summary?.recentSuppliers ?? [];
  const totalSuppliers = summary?.totalSuppliers ?? 0;

  const content = useMemo(() => {
    if (tab === "overview") {
      return (
        <div className="stack-lg">
          <Card>
            <p className="eyebrow">Dashboard</p>
            <h2 className="section-title">Supplier summary</h2>
            <p className="muted">
              A quick view of recent supplier activity from the shared API
              contract.
            </p>
          </Card>

          <div className="stats-grid">
            <Card>
              <p className="muted">Total suppliers</p>
              <h3 className="stat-value">
                {loadingSummary ? "..." : totalSuppliers}
              </h3>
            </Card>
          </div>

          {summaryError ? <p className="error-banner">{summaryError}</p> : null}

          <div className="stack-md">
            {recentSuppliers.length === 0 ? (
              <Card>
                <h3 className="card-title">No suppliers yet</h3>
                <p className="muted">
                  Add a supplier from the Add Supplier tab to see recent
                  activity here.
                </p>
              </Card>
            ) : (
              recentSuppliers.map((supplier) => (
                <Card
                  key={`${supplier.id ?? supplier.companyName}-${supplier.code}`}
                >
                  <h3 className="card-title">{supplier.companyName}</h3>
                  <p className="muted">Code: {supplier.code}</p>
                  <p className="muted">Phone: {supplier.telephoneNumber}</p>
                </Card>
              ))
            )}
          </div>
        </div>
      );
    }

    if (tab === "add") {
      return (
        <Card>
          <div className="stack-md">
            <div>
              <p className="eyebrow">Create</p>
              <h2 className="section-title">Add supplier</h2>
            </div>

            <Input
              label="Code"
              value={form.code}
              error={fieldErrors.code}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, code: e.target.value }))
              }
              placeholder="e.g. 234"
            />

            <Input
              label="Company name"
              value={form.companyName}
              error={fieldErrors.companyName}
              onChange={(e) =>
                setForm((prev) => ({ ...prev, companyName: e.target.value }))
              }
              placeholder="Enter company name"
            />

            <Input
              label="Telephone number"
              value={form.telephoneNumber}
              error={fieldErrors.telephoneNumber}
              onChange={(e) =>
                setForm((prev) => ({
                  ...prev,
                  telephoneNumber: e.target.value,
                }))
              }
              placeholder="Enter telephone number"
            />

            {createError ? <p className="error-banner">{createError}</p> : null}

            <Button
              disabled={loadingCreate}
              onClick={async () => {
                const result = await addSupplier(form);
                setFieldErrors(result ?? {});

                if (!result) {
                  setForm(initialForm);
                  setTab("overview");
                }
              }}
            >
              {loadingCreate ? "Saving..." : "Save supplier"}
            </Button>
          </div>
        </Card>
      );
    }

    return (
      <Card>
        <div className="stack-md">
          <div>
            <p className="eyebrow">Search</p>
            <h2 className="section-title">Find supplier</h2>
          </div>

          <Input
            label="Company name"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by company name"
          />

          {searchError ? <p className="error-banner">{searchError}</p> : null}

          <Button
            disabled={loadingSearch}
            onClick={() => runSearch(searchTerm)}
          >
            {loadingSearch ? "Searching..." : "Search"}
          </Button>

          <div className="stack-md">
            {searchResults.length === 0 ? (
              <p className="muted">No suppliers found yet.</p>
            ) : (
              searchResults.map((supplier) => (
                <Card
                  key={`${supplier.id ?? supplier.companyName}-${supplier.code}`}
                >
                  <h3 className="card-title">{supplier.companyName}</h3>
                  <p className="muted">Code: {supplier.code}</p>
                  <p className="muted">Phone: {supplier.telephoneNumber}</p>
                </Card>
              ))
            )}
          </div>
        </div>
      </Card>
    );
  }, [
    tab,
    summaryError,
    recentSuppliers,
    totalSuppliers,
    loadingSummary,
    form,
    fieldErrors,
    createError,
    loadingCreate,
    searchTerm,
    searchError,
    loadingSearch,
    searchResults,
    addSupplier,
    runSearch,
  ]);

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div>
          <p className="eyebrow"></p>
          <h1 className="app-title">Supplier Portal</h1>
        </div>

        <nav className="nav-list">
          <button
            className={`nav-item ${tab === "overview" ? "nav-item-active" : ""}`}
            onClick={() => setTab("overview")}
          >
            Overview
          </button>
          <button
            className={`nav-item ${tab === "add" ? "nav-item-active" : ""}`}
            onClick={() => setTab("add")}
          >
            Add Supplier
          </button>
          <button
            className={`nav-item ${tab === "search" ? "nav-item-active" : ""}`}
            onClick={() => setTab("search")}
          >
            Search
          </button>
        </nav>
      </aside>

      <main className="content">{content}</main>
    </div>
  );
}
