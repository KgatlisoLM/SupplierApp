import { createApiClient } from '@supplier/shared';

const baseUrl = import.meta.env.VITE_API_URL ?? '';
console.log('WEB API URL:', baseUrl);

export const api = createApiClient(baseUrl);
